# v1.0 2022-03-22 Perl Asana export to WeKan ® release

This release adds the following new features:

- [Added Perl scripts for Asana export to WeKan ®](https://github.com/wekan/wekan/commit/376bcbb373d16317060adc2b1154cc20496775cc).
  Thanks to GeekRuthie.

Thanks to above GitHub users for their contributions and translators for their translations.
