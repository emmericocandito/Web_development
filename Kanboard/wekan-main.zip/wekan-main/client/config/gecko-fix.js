if (Object.prototype.hasOwnProperty('watch')) {
  Object.prototype.watch = undefined;
  Object.prototype.unwatch = undefined;
}
