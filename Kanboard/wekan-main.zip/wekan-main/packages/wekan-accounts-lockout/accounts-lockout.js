import AccountsLockout from './src/accountsLockout';

const Name = 'wekan-accounts-lockout';

export { Name, AccountsLockout };
