module.exports.models = {
  connection: 'mongodb',
  migrate: 'safe',
};
