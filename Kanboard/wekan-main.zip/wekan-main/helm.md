# WeKan Helm Charts

## Webpage

https://wekan.github.io/charts/

## ArtifactHub

https://artifacthub.io/packages/helm/wekan/wekan

## Code

https://github.com/wekan/charts/tree/main/wekan

## Issues

https://github.com/wekan/charts/issues

## Pull Requests

https://github.com/wekan/charts/pulls

## Releases

https://github.com/wekan/charts/tree/gh-pages
