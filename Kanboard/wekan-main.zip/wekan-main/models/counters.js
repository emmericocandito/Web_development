Counters = new Mongo.Collection('counters');
