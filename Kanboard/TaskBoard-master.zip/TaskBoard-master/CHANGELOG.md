## v1.0.2

### New Features

* German translation - Thanks to @ben-so

### Updates

* N/A

### Bug Fixes

* New user creation defaults Security Level to User
* Drag-and-drop automatic actions correctly update UI
* Special characters in emails now handled correctly - Contributed by @ben-so
* Changing card order now updates UI correctly
* Token refresh no longer causes user to be logged out
* Minor fixes for Spanish translations

## v1.0.1

### New Features

* N/A

### Updates

* Made base href dynamic, so there is no need to alter it after 'install'

### Bug Fixes

* N/A

## v1.0.0

### New Features

* Complete re-write
* Conversion script for migrating to new database format (sqlite only)

### Updates

* N/A

### Bug Fixes

* N/A
