export class Notification {
  constructor(public type: string = '',
              public text: string = '') {
  }
}

