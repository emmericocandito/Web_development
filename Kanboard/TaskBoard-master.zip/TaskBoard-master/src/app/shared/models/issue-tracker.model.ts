export class IssueTracker {
  constructor(public id: number = 0,
              public url: string = '',
              public regex: string = '') {
  }
}

